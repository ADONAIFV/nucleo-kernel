# 🗺️ Mapa de Implementación Integral: Proyecto NÚCLEO

Este documento es la hoja de ruta técnica definitiva. Mapea cada capacidad funcional (desde la más básica hasta la más avanzada) directamente sobre la estructura de archivos del sistema.

**Etiquetas de Estado:**
- `[YA IMPLEMENTADO]`: Funcionalidad actual y operativa.
- `[NUEVO]`: Requiere creación de un nuevo archivo o módulo.
- `[ACTUALIZACIÓN]`: Añadir nueva capacidad a una lógica existente.
- `[MEJORA]`: Optimizar, expandir o refinar una capacidad ya presente.

---

## 🏗️ 1. SUBSTRATO (`/substrate`)
*Capa de runtime, memoria y ejecución de bajo nivel.*

### `wasm_runtime.rs`
- `[YA IMPLEMENTADO]` Ejecución de binarios WebAssembly.
- `[YA IMPLEMENTADO]` Mapeo de memoria lineal WASM.
- `[ACTUALIZACIÓN]` Soporte para extensiones de memoria (Memory64) para manejar más de 4GB de RAM.
- `[ACTUALIZACIÓN]` Implementación de "Import Objects" dinámicos para exponer funciones del kernel al WASM.
- `[MEJORA]` Optimización de la compilación JIT (Just-In-Time) para reducir el tiempo de arranque de módulos.
- `[MEJORA]` Implementación de "AOT (Ahead-of-Time) Compilation" para cargar módulos ya pre-compilados.
- `[NUEVO]` "Fuel Metering" para limitar la cantidad de instrucciones que un módulo puede ejecutar (evitar bucles infinitos).
- `[NUEVO]` Soporte para "WASM SIMD" para acelerar cálculos matemáticos pesados.

### `mmu.rs`
- `[YA IMPLEMENTADO]` Aislamiento de memoria por agente (Sandboxing).
- `[YA IMPLEMENTADO]` Traducción de direcciones virtuales a físicas.
- `[YA IMPLEMENTADO]` Protección contra acceso fuera de límites (Out-of-bounds).
- `[ACTUALIZACIÓN]` Implementación de "Shared Memory Regions" para comunicación ultrarrápida entre agentes autorizados.
- `[ACTUALIZACIÓN]` Soporte para "Memory Mapping" de archivos directamente en el espacio de direcciones.
- `[MEJORA]` Implementación de "Copy-on-Write" (CoW) para optimizar la creación de clones de agentes.
- `[MEJORA]` Optimización de la tabla de páginas (Page Table) para reducir la latencia de traducción.
- `[NUEVO]` Soporte para "Memory Guard Pages" para detectar y bloquear desbordamientos de búfer inmediatamente.
- `[NUEVO]` Implementación de "Memory Compression" transparente para datos inactivos.

### `scheduler/semantic.rs`
- `[YA IMPLEMENTADO]` Planificación basada en importancia/semántica.
- `[YA IMPLEMENTADO]` Gestión de colas de espera de procesos.
- `[ACTUALIZACIÓN]` Soporte para "Real-Time Priority" (tareas que no pueden tener latencia).
- `[ACTUALIZACIÓN]` Implementación de "Dynamic Time Quanta" (dar más tiempo a procesos eficientes).
- `[MEJORA]` Algoritmo de "Anti-Starvation" para asegurar que los procesos de baja prioridad eventualmente se ejecuten.
- `[MEJORA]` Reducción del "Context Switch Overhead" optimizando el guardado de registros.
- `[NUEVO]` Implementación de "Affinity Scheduling" para asignar agentes a núcleos de CPU específicos.
- `[NUEVO]` Soporte para "Cooperative Multitasking" donde el agente cede el control voluntariamente.

### `process.rs`
- `[YA IMPLEMENTADO]` Definición de estado, ID y permisos del proceso.
- `[YA IMPLEMENTADO]` Gestión del ciclo de vida (Crear $\rightarrow$ Ejecutar $\rightarrow$ Dormir $\rightarrow$ Morir).
- `[ACTUALIZACIÓN]` Añadir "Process Groups" para gestionar conjuntos de agentes como una sola entidad.
- `[ACTUALIZACIÓN]` Implementación de "Process Heritage" (rastrear qué agente creó a cuál).
- `[MEJORA]` Sistema de "Graceful Shutdown" para que los procesos limpien su memoria antes de morir.
- `[NUEVO]` Soporte para "Lightweight Threads" (Fibras) dentro de un mismo agente.
- `[NUEVO]` Implementación de "Process Quotas" (limitar el número de procesos que un agente puede spawnear).

### `memory_store.rs`
- `[YA IMPLEMENTADO]` Almacenamiento temporal de datos de agentes.
- `[YA IMPLEMENTADO]` Gestión de heaps dinámicos.
- `[ACTUALIZACIÓN]` Implementación de "Automatic Garbage Collection" para liberar memoria de módulos descargados.
- `[ACTUALIZACIÓN]` Soporte para "Persistent Memory Mapping" (datos que no se borran al apagar el kernel).
- `[MEJORA]` Compresión de memoria en tiempo real para datos inactivos.
- `[NUEVO]` Sistema de "Memory Tiering" (mover datos entre RAM rápida y almacenamiento lento).
- `[NUEVO]` Implementación de "Zero-Fill" automático al asignar memoria para evitar fugas de datos antiguos.

### `lego.rs`
- `[YA IMPLEMENTADO]` Índice de funciones y símbolos de módulos cargados.
- `[YA IMPLEMENTADO]` Resolución de nombres de funciones en tiempo de ejecución.
- `[ACTUALIZACIÓN]` Soporte para "Dynamic Linking" entre módulos WASM.
- `[ACTUALIZACIÓN]` Implementación de "Versioning" (permitir que dos versiones de un mismo módulo coexistan).
- `[MEJORA]` Cache de resolución de símbolos para acelerar la llamada a funciones externas.
- `[NUEVO]` Sistema de "Capability-Based Access" (el módulo debe presentar un token para usar una función del lego).
- `[NUEVO]` Soporte para "Hot-Reloading de Símbolos" (actualizar la dirección de una función sin recargar el módulo).

### `ipc.rs`
- `[YA IMPLEMENTADO]` Envío de señales básicas entre componentes.
- `[YA IMPLEMENTADO]` Sincronización básica de hilos.
- `[ACTUALIZACIÓN]` Implementación de "Async Message Queues" (colas de mensajes asíncronas).
- `[ACTUALIZACIÓN]` Soporte para "Shared Memory Buffers" para transferencia de datos masivos.
- `[MEJORA]` Soporte para "Zero-Copy IPC" mediante el uso de la Shared Memory de la MMU.
- `[MEJORA]` Implementación de "Priority Messaging" (mensajes urgentes saltan la cola).
- `[NUEVO]` Implementación de "Publish/Subscribe" (PubSub) para eventos globales del sistema.
- `[NUEVO]` Soporte para "Remote IPC" (comunicación entre kernels en diferentes máquinas).

### `workspace.rs`
- `[YA IMPLEMENTADO]` Gestión de espacio de trabajo temporal por agente.
- `[YA IMPLEMENTADO]` Aislamiento de archivos por ID de agente.
- `[ACTUALIZACIÓN]` Soporte para "Virtual File System" (VFS) para que el agente crea que escribe en disco pero escribe en RAM.
- `[ACTUALIZACIÓN]` Implementación de "Snapshotting de Workspace" (guardar el estado de los archivos).
- `[MEJORA]` Indexación de archivos en el workspace para búsquedas rápidas.
- `[NUEVO]` Sincronización automática del workspace con el almacenamiento persistente.
- `[NUEVO]` Soporte para "Read-Only Layers" (compartir archivos base entre muchos agentes).

---

## 🧠 2. KERNEL (`/kernel`)
*Capa de gestión, gobernanza y orquestación.*

### `main.rs`
- `[YA IMPLEMENTADO]` Secuencia de arranque del sistema.
- `[YA IMPLEMENTADO]` Inicialización de componentes críticos.
- `[ACTUALIZACIÓN]` Implementación de "Boot-up Sequence Configuration" vía archivo externo.
- `[ACTUALIZACIÓN]` Soporte para "Safe Mode" (arrancar solo con módulos básicos si hay errores).
- `[MEJORA]` Paralelización del inicio de servicios críticos para reducir el tiempo de arranque.
- `[NUEVO]` "Health Check de Arranque" (verificar que cada componente responda antes de pasar al siguiente).

### `daemon.rs`
- `[YA IMPLEMENTADO]` Ejecución del kernel en segundo plano.
- `[YA IMPLEMENTADO]` Gestión de PID del proceso maestro.
- `[ACTUALIZACIÓN]` Soporte para "Auto-Restart" en caso de crash crítico.
- `[ACTUALIZACIÓN]` Implementación de "Log Rotation" interno para el daemon.
- `[MEJORA]` Gestión de señales de sistema (SIGTERM, SIGINT) para apagados limpios.
- `[NUEVO]` "Watchdog Timer" (si el kernel no responde en X segundos, el daemon lo reinicia).

### `governor.rs`
- `[YA IMPLEMENTADO]` Asignación de cuotas de CPU y RAM.
- `[YA IMPLEMENTADO]` Monitoreo de consumo por agente.
- `[ACTUALIZACIÓN]` "Dynamic Quota Adjustment" basado en la carga del sistema.
- `[ACTUALIZACIÓN]` Implementación de "Fair Share Scheduling" (repartir equitativamente entre grupos).
- `[MEJORA]` Implementación de "Hard Limits" vs "Soft Limits" (permitir picos de consumo temporales).
- `[MEJORA]` "Priority Boost" temporal para agentes que completan tareas rápidas.
- `[NUEVO]` Sistema de "Credit-Based Scheduling" (los agentes ganan créditos por eficiencia).
- `[NUEVO]` "Resource Locking" (reservar CPU/RAM para una tarea crítica).

### `hot_patch.rs`
- `[YA IMPLEMENTADO]` Reemplazo de módulos en memoria.
- `[YA IMPLEMENTADO]` Carga de nuevos binarios .wasm.
- `[ACTUALIZACIÓN]` "Atomic Module Swapping" (asegurar que el módulo se cambie exactamente entre dos instrucciones).
- `[ACTUALIZACIÓN]` "State Transfer" (mover los datos del módulo viejo al nuevo para no perder el estado).
- `[MEJORA]` "Auto-Rollback" automático si el nuevo módulo genera un crash en los primeros 100ms.
- `[MEJORA]` "Hot-Patch Validation" (ejecutar el módulo en un sandbox antes de ponerlo en producción).
- `[NUEVO]` "Dependency Tracking" (si actualizo el Módulo A, el sistema avisa que el Módulo B debe actualizarse también).
- `[NUEVO]` "Partial Patching" (actualizar solo una función específica en lugar de todo el módulo).

### `metrics.rs`
- `[YA IMPLEMENTADO]` Medición de uso de recursos y errores.
- `[YA IMPLEMENTADO]` Registro de eventos del sistema.
- `[ACTUALIZACIÓN]` Exportación de métricas en formato Prometheus/Grafana.
- `[ACTUALIZACIÓN]` Soporte para "Real-time Dashboarding" vía WebSocket.
- `[MEJORA]` Implementación de "Anomaly Detection" básica (avisar si un agente empieza a consumir RAM de forma exponencial).
- `[MEJORA]` "Trazabilidad de Llamadas" (rastrear una petición desde la CLI $\rightarrow$ Kernel $\rightarrow$ Substrato).
- `[NUEVO]` "Heatmap" de ejecución para identificar qué funciones del kernel son el cuello de botella.
- `[NUEVO]` "System Health Score" (calificación numérica de la estabilidad actual).

### `persistence/checkpoint.rs`
- `[YA IMPLEMENTADO]` Captura de estado (snapshot) de agentes.
- `[YA IMPLEMENTADO]` Guardado y carga de memoria desde disco.
- `[ACTUALIZACIÓN]` "Incremental Checkpoints" (guardar solo lo que cambió desde la última foto).
- `[ACTUALIZACIÓN]` Soporte para "Remote Checkpoints" (guardar la foto en un servidor externo).
- `[MEJORA]` Compresión LZ4 de los checkpoints para ahorrar espacio en disco.
- `[MEJORA]` "Snapshot Validation" (verificar que el checkpoint no esté corrupto antes de cargarlo).
- `[NUEVO]` "Time-Travel Debugging" (capacidad de cargar un checkpoint y ejecutar el código paso a paso hacia atrás).
- `[NUEVO]` "Automatic Recovery" (si el sistema cae, carga el último checkpoint válido automáticamente).

### `wal.rs`
- `[YA IMPLEMENTADO]` Registro de operaciones previas a la escritura.
- `[YA IMPLEMENTADO]` Recuperación de datos tras crash.
- `[ACTUALIZACIÓN]` "WAL Log Rotation" para evitar que el archivo de log crezca infinitamente.
- `[ACTUALIZACIÓN]` Soporte para "Checkpoint-based Truncation" (borrar logs viejos ya persistidos).
- `[MEJORA]` Paralelización de la escritura del log mediante buffers asíncronos.
- `[MEJORA]` "Log Compression" en tiempo real.
- `[NUEVO]` "Log Replication" para enviar el WAL a otro nodo en tiempo real (Alta Disponibilidad).
- `[NUEVO]` "Audit Log" (registro inalterable de quién hizo qué en el sistema).

### `syscalls/basic.rs`
- `[YA IMPLEMENTADO]` Solicitudes básicas de recursos.
- `[YA IMPLEMENTADO]` Gestión de entrada/salida básica.
- `[ACTUALIZACIÓN]` Estandarización de errores de syscall (códigos de error universales).
- `[ACTUALIZACIÓN]` Soporte para "Non-blocking Syscalls" (no detener el proceso mientras se espera la respuesta).
- `[MEJORA]` Implementación de "Syscall Batching" (enviar varias peticiones en una sola llamada).
- `[NUEVO]` "Syscall Filtering" (bloquear ciertas syscalls para agentes no autorizados).

### `syscalls/advanced.rs`
- `[YA IMPLEMENTADO]` Gestión de módulos y agentes.
- `[YA IMPLEMENTADO]` Ejecución de comandos de administración.
- `[ACTUALIZACIÓN]` Syscall para "Query State" (obtener el estado interno de cualquier componente del kernel).
- `[ACTUALIZACIÓN]` Soporte para "Priority Escalation" (pedir temporalmente más permisos).
- `[MEJORA]` Validación de firmas digitales antes de ejecutar una syscall avanzada.
- `[MEJORA]` "Syscall Rate Limiting" (evitar que la CLI sature el kernel con peticiones).
- `[NUEVO]` Syscall para "Trigger Hot-Patch" desde el propio código de un agente (Auto-actualización).
- `[NUEVO]` "Kernel-Level Debugging" (syscall para leer registros internos del CPU simulado).

### `governance/inspector.rs`
- `[YA IMPLEMENTADO]` Auditoría de comportamiento de agentes.
- `[YA IMPLEMENTADO]` Monitoreo de fugas de memoria.
- `[ACTUALIZACIÓN]` "Behavioral Profiling" (detectar patrones de ataque como escaneo de memoria).
- `[ACTUALIZACIÓN]` Implementación de "Security Policies" (reglas escritas en JSON que el inspector debe aplicar).
- `[MEJORA]` Generación de reportes automáticos de salud del sistema.
- `[MEJORA]` "Real-time Alerting" (enviar avisos inmediatos al administrador).
- `[NUEVO]` "Kill-Switch" automático basado en reglas de seguridad predefinidas.
- `[NUEVO]` "Automatic Quarantine" (aislar a un agente sospechoso sin matarlo).

### `distributed/` (Sistemas Distribuidos)
- `[NUEVO] cluster.rs`: Gestión de unión y salida de nodos del cluster.
- `[NUEVO] discovery.rs`: Sistema de descubrimiento automático de otros kernels en la red.
- `[NUEVO] replication.rs`: Sincronización de memoria de agentes entre nodos (Migración de Agentes).
- `[NUEVO] consensus.rs`: Implementación de Raft o Paxos para asegurar que todos los nodos estén de acuerdo en el estado del sistema.
- `[NUEVO] load_balancer.rs`: Repartir los agentes entre los nodos del cluster según la carga.

---

## 🔌 3. HAL (`/hal`)
*Abstracción de hardware.*

### `arch/linux.rs`
- `[YA IMPLEMENTADO]` Traducción de órdenes a Linux.
- `[YA IMPLEMENTADO]` Mapeo de memoria y archivos.
- `[ACTUALIZACIÓN]` Soporte para "Direct I/O" para saltar el cache del OS y ganar velocidad.
- `[ACTUALIZACIÓN]` Implementación de "Zero-Copy Networking" para acelerar la comunicación externa.
- `[MEJORA]` Optimización de llamadas a `mmap` para la gestión de memoria del substrato.
- `[MEJORA]` Soporte para "Huge Pages" en Linux para reducir fallos de página.

### `platform.rs` & `traits.rs`
- `[YA IMPLEMENTADO]` Definición de interfaces estándar.
- `[YA IMPLEMENTADO]` Contratos de hardware.
- `[ACTUALIZACIÓN]` Añadir soporte para "Hardware Accelerators" (GPU/TPU) en los traits.
- `[ACTUALIZACIÓN]` Soporte para "Energy Management" (medir y limitar el consumo energético).
- `[NUEVO] android.rs`: Implementación específica para optimizar el kernel en entornos Android/Termux.
- `[NUEVO] cloud_native.rs`: Optimización para entornos de contenedores (Docker/K8s).

---

## 🎮 4. CLI (`/nucleo-cli`)
*Interfaz de control.*

### `main.rs`
- `[YA IMPLEMENTADO]` Comandos de administración y Hot-Patching.
- `[YA IMPLEMENTADO]` Gestión de módulos y estado del kernel.
- `[ACTUALIZACIÓN]` Modo interactivo (Shell propia de Núcleo) la CLI se convierte en un terminal interactivo.
- `[ACTUALIZACIÓN]` Soporte para "Autocomplete" en los comandos de la CLI.
- `[MEJORA]` Soporte para scripts de automatización (`.ncl` files) para ejecutar series de comandos.
- `[MEJORA]` "Visual Progress Bars" para procesos largos como el Hot-Patching.
- `[NUEVO]` "Remote CLI" (conectarse al kernel vía TCP/IP desde otra máquina).
- `[NUEVO]` "JSON Output Mode" (permitir que la CLI exporte datos en JSON para ser usados por otras apps).

---

## 🧩 5. MÓDULOS Y CONFIGURACIÓN

### `/modules`
- `[YA IMPLEMENTADO]` Binarios .wasm y .wat.
- `[YA IMPLEMENTADO]` Módulos de prueba (v1, v2).
- `[ACTUALIZACIÓN]` "Standard Library of Modules": Crear una colección de módulos básicos (Network, Crypto, Math) preinstalados.
- `[ACTUALIZACIÓN]` Soporte para "Module Signing" (firmas digitales para asegurar que el módulo es oficial).
- `[MEJORA]` "Module Compression" para reducir el tamaño de los binarios WASM.
- `[NUEVO]` "Module Marketplace" (sistema para importar módulos firmados desde repositorios externos).
- `[NUEVO]` "Inter-Module Dependency Graph" (mapa de qué módulo depende de cuál).

### `nucleo.toml`
- `[YA IMPLEMENTADO]` Configuración de límites y carga inicial.
- `[YA IMPLEMENTADO]` Definición de rutas de datos.
- `[ACTUALIZACIÓN]` Soporte para "Environment Profiles" (Dev, Test, Prod) en el mismo archivo.
- `[ACTUALIZACIÓN]` Implementación de "Hot-Reloading de Config" (cambiar la config sin reiniciar el kernel).
- `[MEJORA]` Validación de esquema para evitar errores de sintaxis al cargar la config.
- `[NUEVO]` "Dynamic Rules" (definir reglas de gobernanza directamente en el .toml).
