//! Gestión de workspaces aislados por agente.
//! Permite el uso de un VFS (Virtual File System) con caché en RAM y snapshots.

use crate::AgentId;
use crate::untrusted::Untrusted;
use alloc::string::String;
use alloc::vec::Vec;
use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, thiserror::Error)]
pub enum WorkspaceError {
    #[error("Permiso denegado")]
    PermissionDenied,
    #[error("No encontrado")]
    NotFound,
    #[error("Ya existe")]
    AlreadyExists,
    #[error("Ruta inválida")]
    InvalidPath,
    #[error("Error de E/S: {0}")]
    IoError(String),
}

pub struct Workspace {
    root_dir: PathBuf,
    vfs_cache: Mutex<HashMap<PathBuf, Vec<u8>>>,
}

impl Workspace {
    pub fn new(agent_id: u64, base_dir: &Path) -> Result<Self, WorkspaceError> {
        let root_dir = base_dir.join(format!("agent_workspaces/{}", agent_id));
        fs::create_dir_all(&root_dir).map_err(|e| WorkspaceError::IoError(e.to_string()))?;

        Ok(Self { 
            root_dir,
            vfs_cache: Mutex::new(HashMap::new()),
        })
    }

    fn resolve_path(&self, untrusted_path: Untrusted<&str>) -> Result<PathBuf, WorkspaceError> {
        let path = PathBuf::from(untrusted_path.as_ref());
        let resolved_path = self.root_dir.join(&path);
        let canonical_root = self.root_dir.canonicalize().map_err(|e| WorkspaceError::IoError(e.to_string()))?;
        let canonical_resolved = resolved_path.canonicalize().map_err(|e| WorkspaceError::IoError(e.to_string()))?;

        if !canonical_resolved.starts_with(&canonical_root) {
            return Err(WorkspaceError::InvalidPath);
        }
        Ok(resolved_path)
    }

    pub fn read(&self, untrusted_path: Untrusted<&str>) -> Result<Vec<u8>, WorkspaceError> {
        let resolved_path = self.resolve_path(untrusted_path)?;
        
        {
            let cache = self.vfs_cache.lock().unwrap();
            if let Some(data) = cache.get(&resolved_path) {
                return Ok(data.clone());
            }
        }

        let data = fs::read(&resolved_path).map_err(|e| match e.kind() {
            std::io::ErrorKind::PermissionDenied => WorkspaceError::PermissionDenied,
            std::io::ErrorKind::NotFound => WorkspaceError::NotFound,
            _ => WorkspaceError::IoError(e.to_string()),
        })?;

        let mut cache = self.vfs_cache.lock().unwrap();
        cache.insert(resolved_path, data.clone());
        
        Ok(data)
    }

    pub fn write(&self, untrusted_path: Untrusted<&str>, content: &[u8]) -> Result<(), WorkspaceError> {
        let resolved_path = self.resolve_path(untrusted_path)?;
        
        {
            let mut cache = self.vfs_cache.lock().unwrap();
            cache.insert(resolved_path.clone(), content.to_vec());
        }

        if let Some(parent) = resolved_path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
            }
        }
        fs::write(&resolved_path, content).map_err(|e| match e.kind() {
            std::io::ErrorKind::PermissionDenied => WorkspaceError::PermissionDenied,
            _ => WorkspaceError::IoError(e.to_string()),
        })
    }

    pub fn list(&self, untrusted_path: Untrusted<&str>) -> Result<Vec<String>, WorkspaceError> {
        let resolved_path = self.resolve_path(untrusted_path)?;
        let mut files = Vec::new();
        for entry in fs::read_dir(&resolved_path).map_err(|e| WorkspaceError::IoError(e.to_string()))? {
            let entry = entry.map_err(|e| WorkspaceError::IoError(e.to_string()))?;
            files.push(entry.file_name().to_string_lossy().to_string());
        }
        Ok(files)
    }

    pub fn delete(&self, untrusted_path: Untrusted<&str>) -> Result<(), WorkspaceError> {
        let resolved_path = self.resolve_path(untrusted_path)?;
        {
            let mut cache = self.vfs_cache.lock().unwrap();
            cache.remove(&resolved_path);
        }
        if resolved_path.is_file() {
            fs::remove_file(&resolved_path).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
        } else {
            fs::remove_dir_all(&resolved_path).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
        }
        Ok(())
    }

    pub fn exists(&self, untrusted_path: Untrusted<&str>) -> Result<bool, WorkspaceError> {
        let resolved_path = self.resolve_path(untrusted_path)?;
        Ok(resolved_path.exists())
    }

    pub fn root(&self) -> &Path {
        &self.root_dir
    }

    pub fn create_snapshot(&self) -> Result<PathBuf, WorkspaceError> {
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let snapshot_path = self.root_dir.join(format!("snapshot_{}", timestamp));
        fs::create_dir_all(&snapshot_path).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
        
        for entry in fs::read_dir(&self.root_dir).map_err(|e| WorkspaceError::IoError(e.to_string()))? {
            let entry = entry.map_err(|e| WorkspaceError::IoError(e.to_string()))?;
            let path = entry.path();
            if path.is_file() && !path.to_str().unwrap_or("").contains("snapshot_") {
                fs::copy(&path, &snapshot_path.join(path.file_name().unwrap())).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
            }
        }
        Ok(snapshot_path)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SharePermission { ReadOnly, ReadWrite, WriteOnly }

pub struct SharedWorkspace {
    shared_dirs: Mutex<HashMap<String, SharedDir>>,
}

#[derive(Debug, Clone)]
struct SharedDir {
    path: PathBuf,
    owner: AgentId,
    permissions: HashMap<AgentId, SharePermission>,
}

impl Default for SharedWorkspace {
    fn default() -> Self { Self::new() }
}

impl SharedWorkspace {
    pub fn new() -> Self {
        Self { shared_dirs: Mutex::new(HashMap::new()) }
    }

    pub fn create_shared_dir(&self, name: &str, owner: AgentId, base_path: &Path) -> Result<PathBuf, WorkspaceError> {
        let path = base_path.join("shared").join(name);
        fs::create_dir_all(&path).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
        let mut shared = self.shared_dirs.lock().unwrap();
        shared.insert(name.to_string(), SharedDir { path: path.clone(), owner, permissions: HashMap::new() });
        Ok(path)
    }

    pub fn share_with(&self, name: &str, agent_id: AgentId, permission: SharePermission) -> Result<(), WorkspaceError> {
        let mut shared = self.shared_dirs.lock().unwrap();
        if let Some(dir) = shared.get_mut(name) {
            dir.permissions.insert(agent_id, permission);
            Ok(())
        } else { Err(WorkspaceError::NotFound) }
    }

    pub fn read_shared(&self, name: &str, path: &str, agent_id: AgentId) -> Result<Vec<u8>, WorkspaceError> {
        let shared = self.shared_dirs.lock().unwrap();
        let dir = shared.get(name).ok_or(WorkspaceError::NotFound)?;
        let perm = dir.permissions.get(&agent_id).unwrap_or(&SharePermission::ReadOnly);
        if matches!(perm, SharePermission::ReadOnly | SharePermission::ReadWrite) {
            fs::read(dir.path.join(path)).map_err(|e| WorkspaceError::IoError(e.to_string()))
        } else { Err(WorkspaceError::PermissionDenied) }
    }

    pub fn write_shared(&self, name: &str, path: &str, data: &[u8], agent_id: AgentId) -> Result<(), WorkspaceError> {
        let shared = self.shared_dirs.lock().unwrap();
        let dir = shared.get(name).ok_or(WorkspaceError::NotFound)?;
        let perm = dir.permissions.get(&agent_id).unwrap_or(&SharePermission::ReadOnly);
        if matches!(perm, SharePermission::ReadWrite | SharePermission::WriteOnly) {
            let full_path = dir.path.join(path);
            if let Some(parent) = full_path.parent() { fs::create_dir_all(parent).ok(); }
            fs::write(&full_path, data).map_err(|e| WorkspaceError::IoError(e.to_string()))
        } else { Err(WorkspaceError::PermissionDenied) }
    }

    pub fn list_shared(&self, name: &str, path: &str, agent_id: AgentId) -> Result<Vec<String>, WorkspaceError> {
        let shared = self.shared_dirs.lock().unwrap();
        let dir = shared.get(name).ok_or(WorkspaceError::NotFound)?;
        let perm = dir.permissions.get(&agent_id).unwrap_or(&SharePermission::ReadOnly);
        if matches!(perm, SharePermission::ReadOnly | SharePermission::ReadWrite) {
            let entries = fs::read_dir(dir.path.join(path)).map_err(|e| WorkspaceError::IoError(e.to_string()))?;
            Ok(entries.flatten().map(|e| e.file_name().to_string_lossy().to_string()).collect())
        } else { Err(WorkspaceError::PermissionDenied) }
    }
}
