#![allow(clippy::module_inception)]

//! Comunicación entre agentes (pub/sub).
//! Permite que los agentes se envíen mensajes entre sí de forma asíncrona.

use crate::AgentId;
use crossbeam_channel::{Receiver, RecvError, Sender, TrySendError, bounded};
use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use thiserror::Error;

/// Mensaje enviado entre agentes.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Message {
    pub from: AgentId,
    pub to: Option<AgentId>, // None = broadcast
    pub topic: String,
    pub payload: String,
    pub timestamp: u64,
}

impl Message {
    pub fn empty() -> Self {
        Self {
            from: AgentId(0),
            to: None,
            topic: String::new(),
            payload: String::new(),
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
        }
    }
}

/// Bus de mensajes para comunicación entre agentes.
pub struct MessageBus {
    topics: Mutex<HashMap<String, Vec<Sender<Message>>>>,
    agent_queues: Mutex<HashMap<AgentId, Sender<Message>>>,
    // Colas de prioridad para mensajes críticos
    priority_queue: Mutex<VecDeque<Message>>, 
    _next_id: Arc<Mutex<u64>>,
}

impl Default for MessageBus {
    fn default() -> Self {
        Self::new()
    }
}

impl MessageBus {
    pub fn new() -> Self {
        Self {
            topics: Mutex::new(HashMap::new()),
            agent_queues: Mutex::new(HashMap::new()),
            priority_queue: Mutex::new(VecDeque::new()),
            _next_id: Arc::new(Mutex::new(0)),
        }
    }

    /// Registra un agente en el bus y devuelve un receptor para sus mensajes.
    pub fn register_agent(&self, agent_id: AgentId) -> Receiver<Message> {
        let (tx, rx) = bounded(1024);
        self.agent_queues.lock().unwrap().insert(agent_id, tx);
        rx
    }

    /// Desregistra un agente del bus.
    pub fn unregister_agent(&self, agent_id: AgentId) {
        self.agent_queues.lock().unwrap().remove(&agent_id);
        let empty_msg = Message::empty();
        let mut topics = self.topics.lock().unwrap();
        for (_, senders) in topics.iter_mut() {
            senders.retain(|tx| match tx.try_send(empty_msg.clone()) {
                Ok(_) => true,
                Err(TrySendError::Disconnected(_)) => false,
                Err(TrySendError::Full(_)) => true,
            });
        }
    }

    /// Publica un mensaje en un tema (PubSub Asíncrono).
    pub fn publish(&self, topic: &str, message: Message) -> Result<(), IpcError> {
        let topics = self.topics.lock().unwrap();
        if let Some(senders) = topics.get(topic) {
            for sender in senders {
                if let Err(e) = sender.try_send(message.clone()) {
                    match e {
                        TrySendError::Full(_) => {
                            tracing::warn!("Canal de tópico {} lleno, mensaje descartado", topic);
                        }
                        TrySendError::Disconnected(_) => {
                            tracing::error!("Receptor desconectado en tópico {}", topic);
                        }
                    }
                }
            }
        }
        Ok(())
    }

    /// Suscribe un agente a un tema.
    pub fn subscribe(&self, agent_id: AgentId, topic: &str) -> Result<(), IpcError> {
        let mut topics = self.topics.lock().unwrap();
        let entry = topics.entry(topic.to_string()).or_default();
        let agent_queues = self.agent_queues.lock().unwrap();
        if let Some(tx) = agent_queues.get(&agent_id) {
            entry.push(tx.clone());
            Ok(())
        } else {
            Err(IpcError::AgentNotFound(agent_id))
        }
    }

    /// Envía un mensaje directamente a un agente.
    pub fn send_to_agent(
        &self,
        from: AgentId,
        to: AgentId,
        payload: String,
    ) -> Result<(), IpcError> {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let message = Message {
            from,
            to: Some(to),
            topic: "direct".to_string(),
            payload,
            timestamp,
        };

        let agent_queues = self.agent_queues.lock().unwrap();
        if let Some(tx) = agent_queues.get(&to) {
            tx.send(message).map_err(|_| IpcError::SendError)?;
            Ok(())
        } else {
            Err(IpcError::AgentNotFound(to))
        }
    }

    pub fn get_agent_receiver(&self, _agent_id: AgentId) -> Receiver<Message> {
        let (_tx, rx) = bounded(1024);
        rx
    }
}

#[derive(Debug, Error)]
pub enum IpcError {
    #[error("Agente {0} no encontrado")]
    AgentNotFound(AgentId),
    #[error("Error al enviar mensaje")]
    SendError,
    #[error("Error al recibir mensaje")]
    ReceiveError,
    #[error("Timeout al recibir mensaje")]
    Timeout,
    #[error("Funcionalidad no implementada")]
    NotImplemented,
}

impl From<RecvError> for IpcError {
    fn from(_err: RecvError) -> Self {
        IpcError::ReceiveError
    }
}
