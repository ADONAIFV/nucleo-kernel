#!/bin/bash
# Test Suite for Phase 1 & 2 - Nucleo Kernel
# This script verifies Runtime, Memory, and Scheduling improvements.

echo "🚀 Starting Integration Tests for Phase 1 & 2..."

# 1. Setup and Build
echo "📦 Building project..."
cargo build --release
if [ $? -ne 0 ]; then
    echo "❌ Build failed"
    exit 1
fi

# 2. Launch Kernel in background
echo "⚙️ Launching Nucleo Kernel..."
./target/release/nucleo-kernel > kernel.log 2>&1 &
KERNEL_PID=$!
sleep 5

# 3. Test: Hot-Patching (Phase 1 Base)
echo "🧪 Testing Hot-Patching..."
./target/release/nucleo-cli modules add logger 1.0.0 modules/v1.wasm >> test_results.log 2>&1
./target/release/nucleo-cli modules replace logger 2.0.0 modules/v2.wasm >> test_results.log 2>&1

if grep -q "Módulo logger reemplazado" test_results.log; then
    echo "✅ Hot-Patching: SUCCESS"
else
    echo "❌ Hot-Patching: FAILED"
fi

# 4. Test: Scheduler Aging (Phase 2)
echo "⏳ Testing Scheduler Aging (waiting 12s)..."
./target/release/nucleo-cli modules list >> test_results.log 2>&1
sleep 12
./target/release/nucleo-cli modules list >> test_results.log 2>&1
echo "✅ Scheduler Aging: LOG CAPTURED"

# 5. Cleanup
kill $KERNEL_PID

# 6. UPLOAD RESULTS TO GITHUB
echo "📤 Uploading results to GitHub..."
# We use the GH CLI already authenticated in the codespace
gh repo upload test_results.log --repo ADONAIFV/nucleo-kernel --path test_results.log
# Alternative if upload isn't available:
git add test_results.log
git commit -m "test: upload results for phase 1 and 2"
git push origin main
