#!/bin/bash
# Integration Test Suite for Phases 1, 2 & 3 - Nucleo Kernel
# Target: GitHub Codespace

echo "🧪 Starting Integration Tests for Phases 1-3..."
echo "--------------------------------------------"

# 1. Start the Kernel in background
./target/release/nucleo-kernel &
KERNEL_PID=$!
sleep 3 # Give it time to start

if ! pgrep -f nucleo-kernel > /dev/null; then
    echo "❌ ERROR: Kernel failed to start."
    exit 1
fi
echo "✅ Kernel started (PID: $KERNEL_PID)"

# Define a helper for CLI calls
run_cli() {
    ./target/release/nucleo-cli "$@"
}

# --- PHASE 1: Runtime & Memory ---
echo -e "\nTesting Phase 1: Core Runtime & Memory..."
# Test Memory Store / MMU via a dummy module or syscall if available.
# Since we have no specific 'mmu test' command in CLI yet, we verify through system state.
if run_cli system state; then
    echo "✅ Phase 1: System state reachable."
else
    echo "❌ Phase 1: System state unreachable."
fi

# --- PHASE 2: Process & Scheduling ---
echo -e "\nTesting Phase 2: Process & Scheduling..."
# Check if we can get agent status (represents process management)
if run_cli agent status 0; then
    echo "✅ Phase 2: Agent/Process management reachable."
else
    echo "❌ Phase 2: Agent status check failed."
fi

# --- PHASE 3: IPC & Workspaces ---
echo -e "\nTesting Phase 3: IPC & Workspaces..."

# A. IPC Test: Publish and Subscribe
echo "Testing IPC Pub/Sub..."
run_cli ipc publish "test_topic" "Hello Nucleo!"
if run_cli ipc subscribe "test_topic"; then
    echo "✅ IPC: Subscription successful."
else
    echo "❌ IPC: Subscription failed."
fi

# B. Workspace Test: Write, Read, List
echo "Testing Workspace VFS..."
run_cli workspace write "test.txt" "Nucleo VFS Content"
if run_cli workspace read "test.txt" | grep -q "Nucleo VFS Content"; then
    echo "✅ Workspace: Write/Read successful."
else
    echo "❌ Workspace: Write/Read failed."
fi

if run_cli workspace list "."; then
    echo "✅ Workspace: Listing successful."
else
    echo "❌ Workspace: Listing failed."
fi

# C. Snapshot Test
echo "Testing Workspace Snapshot..."
if run_cli workspace snapshot; then
    echo "✅ Workspace: Snapshot created."
else
    echo "❌ Workspace: Snapshot failed."
fi

# --- Cleanup ---
echo -e "\n--------------------------------------------"
echo "Cleaning up..."
kill $KERNEL_PID
echo "✅ Kernel stopped."
echo "🚀 Tests Completed."
