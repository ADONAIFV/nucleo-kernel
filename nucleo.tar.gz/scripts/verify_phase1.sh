#!/bin/bash
# Verification Script for Nucleo Phase 1: Runtime & Memory
echo "🧪 Starting Phase 1 Validation..."

# 1. Unit Tests for Memory & Runtime
echo "--- Checking Unit Tests ---"
cargo test substrate::mmu
cargo test substrate::memory_store
cargo test substrate::wasm_runtime

if [ $? -eq 0 ]; then
    echo "✅ Unit tests passed."
else
    echo "❌ Unit tests failed."
fi

# 2. Functional Test: Fuel Metering
echo "--- Testing Fuel Metering ---"
# Start kernel in background
./target/release/nucleo-kernel > phase1_kernel.log 2>&1 &
KERNEL_PID=$!
sleep 2

# Load a module designed to loop infinitely (if exists) or trigger fuel
# We simulate this by checking if the kernel logs "Fuel limit exceeded"
./target/release/nucleo-cli modules add --name "loop_test" --version "1.0" --wasm "./target/release/modules/infinite_loop.wasm" 2>/dev/null

sleep 2
if grep -q "Fuel limit exceeded" phase1_kernel.log; then
    echo "✅ Fuel Metering: WORKING (Infinite loop caught)."
else
    echo "❌ Fuel Metering: FAILED or no log generated."
fi

# 3. Functional Test: Guard Pages
echo "--- Testing Guard Pages ---"
# Trigger a memory access violation
./target/release/nucleo-cli modules add --name "crash_test" --version "1.0" --wasm "./target/release/modules/out_of_bounds.wasm" 2>/dev/null

sleep 2
if grep -q "Guard page violation" phase1_kernel.log; then
    echo "✅ Guard Pages: WORKING (Illegal access blocked)."
else
    echo "❌ Guard Pages: FAILED or no log generated."
fi

# Cleanup
kill $KERNEL_PID
echo "--- Phase 1 Validation Complete ---"
