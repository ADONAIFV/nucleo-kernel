#!/bin/bash
# Setup environment for Nucleo Kernel in Codespace

echo "⚙️  Preparing environment..."

# Crear directorio de configuraciones
mkdir -p configs

# Crear nucleo.toml básico si no existe
if [ ! -f "configs/nucleo.toml" ]; then
    echo "📝 Creating default nucleo.toml..."
    cat <<EOF > configs/nucleo.toml
[kernel]
name = "Nucleo-Cloud"
version = "0.3.0"
safe_mode = false

[resources]
max_agents = 100
default_memory_mb = 128
max_cpu_percent = 80.0

[logging]
level = "info"
file = "kernel.log"
EOF
else
    echo "✅ nucleo.toml already exists."
fi

# Crear directorios de datos
mkdir -p data/agents
mkdir -p data/workspaces
mkdir -p data/checkpoints

echo "✅ Environment ready."
