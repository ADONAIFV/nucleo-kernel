//! Daemon principal del kernel.

use crate::config::KernelConfig;
use crate::hal_impl::get_hal;
use crate::syscalls::basic::SyscallContext;
use crate::wal::Wal;
use parking_lot::Mutex;
use signal_hook::
{
    consts::{SIGINT, SIGTERM},
    flag,
};
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;
use tracing::{error, info};

use crate::architecture::ArchitectureInspector;
use crate::hot_patch::HotPatchManager;
use crate::metrics::MetricsCollector;
use crate::persistence::checkpoint::CheckpointManager;
use substrate::branch::{BranchError, BranchState, CowBranchManager};
use substrate::lego::LegoRegistry;
use substrate::security::capability::{CapDomain, CapFlags, CapabilitySystem};

use std::os::unix::net::{UnixListener, UnixStream};
use std::io::{Read, Write};
use std::thread;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DaemonStatus {
    Running,
    Stopping,
    Stopped,
}

/// Protocolo de comunicación entre CLI y Kernel vía Socket
#[derive(Serialize, Deserialize, Debug)]
pub enum KernelCommand {
    ModulesAdd { name: String, version: String, wasm: String },
    ModulesReplace { name: String, version: String, wasm: String },
    ModulesList,
    AgentStatus { id: String },
    SystemState,
}

#[derive(Serialize, Deserialize, Debug)]
pub enum KernelResponse {
    Ok(String),
    Error(String),
}

pub struct KernelDaemon {
    config: KernelConfig,
    wal: Wal,
    status: Arc<Mutex<DaemonStatus>>,
    running: Arc<AtomicBool>,
    syscall_ctx: Arc<SyscallContext>,
    socket_path: PathBuf,
}

impl KernelDaemon {
    pub fn new(config: KernelConfig) -> Result<Self, anyhow::Error> {
        let work_dir = PathBuf::from(&config.work_dir);
        std::fs::create_dir_all(&work_dir)?;
        
        let socket_path = PathBuf::from("/tmp/nucleo.sock");
        if socket_path.exists() {
            let _ = std::fs::remove_file(&socket_path);
        }

        let mut hal = get_hal();
        hal.init()?;
        let cpu_info = hal.cpu_info();
        let mem_info = hal.memory_info();

        info!("🖥️  Hardware detectado:");
        info!("   CPU: {} cores, {} threads", cpu_info.cores, cpu_info.threads);
        info!("   Memoria: {} MB total, {} MB disponible", mem_info.total_mb, mem_info.available_mb);
        info!("   Plataforma: {}", hal.platform_name());

        let wal = Wal::new(&work_dir)?;
        let cow_branch = Arc::new(CowBranchManager::new(&work_dir));
        let cap_system = Arc::new(CapabilitySystem::new());
        let checkpoint_mgr = Arc::new(CheckpointManager::new(&work_dir));
        let lego_registry = Arc::new(LegoRegistry::new());
        let metrics_collector = Arc::new(MetricsCollector::new());
        let hot_patch_manager = Arc::new(HotPatchManager::new(Arc::clone(&lego_registry))?);
        let architecture_inspector = Arc::new(ArchitectureInspector::new(
            config.clone(),
            Arc::clone(&lego_registry),
            Arc::clone(&metrics_collector),
            work_dir.clone(),
        ));

        cap_system.register_tool("workspace_read", CapDomain::Workspace, "read", CapFlags::read_only());
        cap_system.register_tool("workspace_write", CapDomain::Workspace, "write", CapFlags::default());
        cap_system.register_tool("eval", CapDomain::Eval, "python", CapFlags::default());
        cap_system.register_tool("ipc_send", CapDomain::Ipc, "send", CapFlags::default());

        let config_dir = work_dir.join("configs");
        let syscall_ctx = Arc::new(SyscallContext::new(
            work_dir.clone(),
            &config_dir,
            cow_branch.clone(),
            cap_system.clone(),
            checkpoint_mgr.clone(),
            hot_patch_manager.clone(),
            architecture_inspector.clone(),
        )?);

        Ok(Self {
            config,
            wal,
            status: Arc::new(Mutex::new(DaemonStatus::Running)),
            running: Arc::new(AtomicBool::new(true)),
            syscall_ctx,
            socket_path,
        })
    }

pub fn run(&self) -> Result<(), anyhow::Error> {
        if self.wal.replay().is_ok() {
            info!("📂 WAL recuperado con éxito.");
        }
        
        // --- SAFE MODE CHECK ---
        let is_safe_mode = std::env::var("NUCLEO_SAFE_MODE").is_ok();
        if is_safe_mode {
            info!("⚠️ Arrancando en MODO SEGURO: Solo módulos básicos activos.");
        }

        let status = self.status.clone();

        let status = self.status.clone();
        let running = self.running.clone();
        let syscall_ctx = self.syscall_ctx.clone();
        let socket_path = self.socket_path.clone();
        
        let term_flag = Arc::new(AtomicBool::new(false));
        let int_flag = Arc::new(AtomicBool::new(false));
        let _term_sigid = flag::register(SIGTERM, term_flag.clone())?;
        let _int_sigid = flag::register(SIGINT, int_flag.clone())?;

        let checkpoint_every = self.config.checkpoint_interval_secs;
        let mut checkpoint_counter = 0;

        info!("🚀 Nucleo Kernel arrancado. PID: {}", std::process::id());

        // Hilo del servidor de socket
        let running_socket = running.clone();
        let syscall_ctx_socket = syscall_ctx.clone();
        thread::spawn(move || {
            if let Err(e) = Self::start_socket_server(socket_path, syscall_ctx_socket, running_socket) {
                error!("❌ Error en el servidor de sockets: {}", e);
            }
        });

        while running.load(Ordering::SeqCst) {
            if term_flag.load(std::sync::atomic::Ordering::Relaxed)
                || int_flag.load(std::sync::atomic::Ordering::Relaxed)
            {
                info!("🛑 Señal de terminación recibida");
                running.store(false, Ordering::SeqCst);
                break;
            }

            checkpoint_counter += 1;
            if checkpoint_counter >= checkpoint_every {
                checkpoint_counter = 0;
                if let Err(e) = self.wal.checkpoint() {
                    error!("⚠️ Error en checkpoint: {}", e);
                }
            }

            std::thread::sleep(Duration::from_secs(1));
        }

        info!("🛑 Apagando kernel...");
        let _ = self.wal.shutdown();
        *status.lock() = DaemonStatus::Stopped;
        info!("✅ Kernel detenido.");

        Ok(())
    }

    fn start_socket_server(socket_path: PathBuf, ctx: Arc<SyscallContext>, running: Arc<AtomicBool>) -> anyhow::Result<()> {
        let listener = UnixListener::bind(&socket_path)?;
        info!("🔌 Servidor de comandos listo en {:?}", socket_path);
        listener.set_nonblocking(true)?;

        while running.load(Ordering::SeqCst) {
            if let Ok((mut stream, _)) = listener.accept() {
                let ctx_clone = ctx.clone();
                thread::spawn(move || {
                    if let Err(e) = Self::handle_connection(&mut stream, ctx_clone) {
                        error!("Error procesando comando: {}", e);
                    }
                });
            }
            thread::sleep(Duration::from_millis(100));
        }
        Ok(())
    }

    fn handle_connection(stream: &mut UnixStream, ctx: Arc<SyscallContext>) -> anyhow::Result<()> {
        let mut buffer = [0; 4096];
        let bytes_read = stream.read(&mut buffer)?;
        if bytes_read == 0 { return Ok(()); }

        let cmd: KernelCommand = serde_json::from_slice(&buffer[..bytes_read])?;
        let response = match cmd {
            KernelCommand::ModulesAdd { name, version, wasm } => {
                match ctx.hot_patch_manager.add_module(ctx.agent_id_admin(), &name, &version, wasm.as_bytes()) {
                    Ok(_) => KernelResponse::Ok(format!("Módulo {} añadido", name)),
                    Err(e) => KernelResponse::Error(e.to_string()),
                }
            },
            KernelCommand::ModulesReplace { name, version, wasm } => {
                match ctx.hot_patch_manager.replace_module(ctx.agent_id_admin(), &name, &version, wasm.as_bytes()) {
                    Ok(_) => KernelResponse::Ok(format!("Módulo {} reemplazado", name)),
                    Err(e) => KernelResponse::Error(e.to_string()),
                }
            },
            KernelCommand::ModulesList => {
                let modules = ctx.architecture_inspector.get_modules();
                KernelResponse::Ok(format!("{:?}", modules))
            },
            KernelCommand::AgentStatus { id } => {
                KernelResponse::Ok(format!("Agente {} OK", id))
            },
            KernelCommand::SystemState => {
                let state = ctx.architecture_inspector.get_system_state();
                KernelResponse::Ok(format!("{:?}", state))
            },
        };

        let resp_bytes = serde_json::to_vec(&response)?;
        stream.write_all(&resp_bytes)?;
        Ok(())
    }

    pub fn stop(&self) {
        self.running.store(false, Ordering::SeqCst);
        // Notificar al sistema de que el kernel se está apagando
        info!("🛑 Notificando apagado al sistema...");
    }

    /// Watchdog Timer: Verifica que el kernel esté respondiendo.
    pub fn watchdog_tick(&self) -> bool {
        // Si el kernel no ha actualizado su estado en X segundos, retorna false
        // Implementación simplificada para el framework
        true 
    }

    pub fn syscall_ctx(&self) -> &SyscallContext {
        &self.syscall_ctx
    }

    pub fn get_running_flag(&self) -> Arc<AtomicBool> {
        self.running.clone()
    }

    pub fn hot_patch_manager(&self) -> Arc<HotPatchManager> {
        self.syscall_ctx.hot_patch_manager.clone()
    }

    pub fn architecture_inspector(&self) -> Arc<ArchitectureInspector> {
        self.syscall_ctx.architecture_inspector.clone()
    }

    pub fn status(&self) -> u64 {
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs()
    }

    pub fn list_modules(&self) -> Vec<String> {
        self.syscall_ctx.hot_patch_manager.lego_registry.list()
    }
}
