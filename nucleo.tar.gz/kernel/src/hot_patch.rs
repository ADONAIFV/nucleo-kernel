//! Gestor de hot-patching para el kernel.
//! Permite reemplazar y añadir módulos en caliente.

use substrate::AgentId;
use substrate::lego::{Health, Lego, LegoRegistry};
use anyhow::Result;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use wasmtime::{Engine, Instance, Linker, Module, Store};

pub struct HotPatchManager {
    engine: Engine,
    linker: Linker<()>,
    pub lego_registry: Arc<LegoRegistry>,
}

impl HotPatchManager {
    pub fn new(lego_registry: Arc<LegoRegistry>) -> Result<Self> {
        let engine = Engine::default();
        let linker = Linker::new(&engine);

        Ok(Self {
            engine,
            linker,
            lego_registry,
        })
    }

    /// Reemplaza un módulo existente en el kernel por una nueva versión WASM.
    pub fn replace_module(
        &self,
        agent_id: AgentId,
        module_name: &str,
        new_version: &str,
        wasm_bytes: &[u8],
    ) -> Result<()> {
        let lego_registry = self.lego_registry.as_ref();

        let old_module = lego_registry
            .get(module_name)
            .ok_or_else(|| anyhow::anyhow!("Módulo {} no encontrado", module_name))?;

        let module = Module::new(&self.engine, wasm_bytes)?;
        let mut store = Store::new(&self.engine, ());
        let instance = self.linker.instantiate(&mut store, &module)?;

        let init_func = instance.get_typed_func::<(), i32>(&mut store, "init")?;
        let init_result = init_func.call(&mut store, ())?;
        if init_result != 0 {
            return Err(anyhow::anyhow!(
                "Init del nuevo módulo falló con código {}",
                init_result
            ));
        }

        let new_lego = Arc::new(WasmLegoAdapter {
            name: module_name.to_string(),
            version: new_version.to_string(),
            instance: Arc::new(Mutex::new(Some((store, instance)))),
            module: Arc::new(module),
            wasm_bytes: wasm_bytes.to_vec(),
        });

        lego_registry.replace(module_name, new_lego)?;

        if let Err(e) = old_module.shutdown() {
            tracing::warn!("Error al apagar módulo antiguo {}: {}", module_name, e);
        }

        tracing::info!(
            "🔄 Módulo {} reemplazado atómicamente por v{} (agente {:?})",
            module_name,
            new_version,
            agent_id
        );

        Ok(())
    }

    /// Añade un nuevo módulo al kernel (Hot-Loading).
    pub fn add_module(
        &self,
        agent_id: AgentId,
        module_name: &str,
        version: &str,
        wasm_bytes: &[u8],
    ) -> Result<()> {
        let lego_registry = self.lego_registry.as_ref();

        let module = Module::new(&self.engine, wasm_bytes)?;
        let mut store = Store::new(&self.engine, ());
        let instance = self.linker.instantiate(&mut store, &module)?;

        let init_func = instance.get_typed_func::<(), i32>(&mut store, "init")?;
        let init_result = init_func.call(&mut store, ())?;
        if init_result != 0 {
            return Err(anyhow::anyhow!(
                "Init del nuevo módulo falló con código {}",
                init_result
            ));
        }

        let new_lego = Arc::new(WasmLegoAdapter {
            name: module_name.to_string(),
            version: version.to_string(),
            instance: Arc::new(Mutex::new(Some((store, instance)))),
            module: Arc::new(module),
            wasm_bytes: wasm_bytes.to_vec(),
        });

        lego_registry.register(new_lego)?;

        tracing::info!(
            "✨ Nuevo módulo '{}' v{} añadido al kernel (agente {:?})",
            module_name,
            version,
            agent_id
        );

        Ok(())
    }
}

struct WasmLegoAdapter {
    name: String,
    version: String,
    instance: Arc<Mutex<Option<(Store<()>, Instance)>>>,
    module: Arc<Module>,
    wasm_bytes: Vec<u8>,
}

impl Lego for WasmLegoAdapter {
    fn name(&self) -> &str {
        &self.name
    }

    fn version(&self) -> &str {
        &self.version
    }

    fn init(&mut self) -> Result<(), anyhow::Error> {
        let mut guard = self.instance.lock().unwrap();
        if let Some((store, instance)) = guard.as_mut() {
            let func = instance.get_typed_func::<(), i32>(&mut *store, "init")?;
            let result = func.call(&mut *store, ())?;
            if result == 0 {
                Ok(())
            } else {
                Err(anyhow::anyhow!("Init falló con código {}", result))
            }
        } else {
            Err(anyhow::anyhow!("Instancia no disponible"))
        }
    }

    fn health(&self) -> Health {
        let mut guard = self.instance.lock().unwrap();
        if let Some((store, instance)) = guard.as_mut() {
            if let Ok(func) = instance.get_typed_func::<(), i32>(&mut *store, "health") {
                if let Ok(result) = func.call(&mut *store, ()) {
                    return match result {
                        0 => Health::Healthy,
                        1 => Health::Degraded,
                        _ => Health::Unhealthy,
                    };
                }
            }
        }
        Health::Unhealthy
    }

    fn shutdown(&self) -> Result<(), anyhow::Error> {
        let mut guard = self.instance.lock().unwrap();
        if let Some((store, instance)) = guard.as_mut() {
            if let Ok(func) = instance.get_typed_func::<(), i32>(&mut *store, "shutdown") {
                let _ = func.call(&mut *store, ());
            }
        }
        *guard = None;
        Ok(())
    }
}
