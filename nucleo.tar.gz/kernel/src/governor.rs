//! Gestor de recursos (CPU, memoria, agentes, etc.)

use crate::config::ResourceLimits;
use parking_lot::Mutex;
use std::collections::HashMap;
use substrate::AgentId;
use std::sync::Arc;

pub struct ResourceGovernor {
    limits: ResourceLimits,
    used_agents: Mutex<usize>,
    used_memory_mb: Mutex<u64>,
    used_fds: Mutex<u64>,
    // Cuotas dinámicas por agente (CPU %, RAM MB)
    quotas: Mutex<HashMap<AgentId, (f32, usize)>>,
    // Sistema de créditos para Scheduling
    credits: Mutex<HashMap<AgentId, i32>>,
}

impl ResourceGovernor {
    pub fn new(limits: ResourceLimits) -> Self {
        Self {
            limits,
            used_agents: Mutex::new(0),
            used_memory_mb: Mutex::new(0),
            used_fds: Mutex::new(0),
            quotas: Mutex::new(HashMap::new()),
            credits: Mutex::new(HashMap::new()),
        }
    }

    pub fn try_alloc_agent(&self) -> bool {
        let mut used = self.used_agents.lock();
        if *used >= self.limits.max_agents {
            false
        } else {
            *used += 1;
            true
        }
    }

    pub fn free_agent(&self) {
        let mut used = self.used_agents.lock();
        if *used > 0 {
            *used -= 1;
        }
    }

    pub fn stats(&self) -> (usize, u64, u64) {
        (
            *self.used_agents.lock(),
            *self.used_memory_mb.lock(),
            *self.used_fds.lock(),
        )
    }

    /// Actualiza cuotas dinámicas para un agente.
    pub fn update_quotas(&self, agent_id: AgentId, cpu_limit: f32, ram_limit: usize) {
        let mut quotas = self.quotas.lock();
        quotas.insert(agent_id, (cpu_limit, ram_limit));
    }

    /// Gestiona el balance de créditos de un agente.
    pub fn apply_credits(&self, agent_id: AgentId, amount: i32) {
        let mut credits = self.credits.lock();
        let entry = credits.entry(agent_id).or_insert(100);
        *entry = (*entry + amount).clamp(0, 1000);
    }
}
