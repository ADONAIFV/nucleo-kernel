//! CLI de administración para Nucleo Kernel.
//! Comunicación vía Unix Domain Sockets (UDS).

use anyhow::{anyhow, Result};
use clap::{Parser, Subcommand, Args};
use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use serde::{Serialize, Deserialize};

#[derive(Parser)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Modules(ModuleCommands),
    Agent(AgentCommands),
    System(SystemCommands),
    Ipc(IpcCommands),
    Workspace(WorkspaceCommands),
    Debug(DebugCommands),
}

#[derive(Args)]
struct ModuleCommands {
    #[command(subcommand)]
    command: ModuleSubcommands,
}

#[derive(Subcommand)]
enum ModuleSubcommands {
    Add { name: String, #[arg(long)] version: String, #[arg(long)] wasm: PathBuf, #[arg(long)] admin: bool },
    Replace { name: String, #[arg(long)] version: String, #[arg(long)] wasm: PathBuf, #[arg(long)] admin: bool },
    List { #[arg(long)] admin: bool },
}

#[derive(Args)]
struct AgentCommands {
    #[command(subcommand)]
    command: AgentSubcommands,
}

#[derive(Subcommand)]
enum AgentSubcommands {
    Status { id: String },
    Kill { id: String },
}

#[derive(Args)]
struct SystemCommands {
    #[command(subcommand)]
    action: SystemActions,
}

#[derive(Subcommand)]
enum SystemActions {
    State,
    Reset,
}

#[derive(Args)]
struct IpcCommands {
    #[command(subcommand)]
    command: IpcSubcommands,
}

#[derive(Subcommand)]
enum IpcSubcommands {
    Publish { topic: String, payload: String },
    Subscribe { topic: String },
    Recv { timeout: u64 },
    ListTopics,
}

#[derive(Args)]
struct WorkspaceCommands {
    #[command(subcommand)]
    command: WorkspaceSubcommands,
}

#[derive(Subcommand)]
enum WorkspaceSubcommands {
    Write { path: String, content: String },
    Read { path: String },
    List { path: String },
    Snapshot,
    Status,
}

#[derive(Args)]
struct DebugCommands {
    #[command(subcommand)]
    command: DebugSubcommands,
}

#[derive(Subcommand)]
enum DebugSubcommands {
    Kernel,
    Memory,
    Scheduler,
    Process,
    Tracing,
}

#[derive(Serialize, Deserialize, Debug)]
pub enum KernelCommand {
    ModulesAdd { name: String, version: String, wasm: String },
    ModulesReplace { name: String, version: String, wasm: String },
    ModulesList,
    AgentStatus { id: String },
    SystemState,
    IpcPublish { topic: String, payload: String },
    IpcSubscribe { topic: String },
    IpcRecv { timeout: u64 },
    IpcListTopics,
    WorkspaceWrite { path: String, content: String },
    WorkspaceRead { path: String },
    WorkspaceList { path: String },
    WorkspaceSnapshot,
    WorkspaceStatus,
    DebugKernel,
    DebugMemory,
    DebugScheduler,
    DebugProcess,
    DebugTracing,
}

#[derive(Serialize, Deserialize, Debug)]
pub enum KernelResponse {
    Ok(String),
    Error(String),
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let socket_path = "/tmp/nucleo.sock";

    let mut stream = UnixStream::connect(socket_path)
        .map_err(|e| anyhow!("No se pudo conectar al kernel en {}. ¿Está corriendo el daemon? ({})", socket_path, e))?;

    let cmd = match &cli.command {
        Commands::Modules(cmd) => match &cmd.command {
            ModuleSubcommands::Add { name, version, wasm, admin } => {
                let wasm_str = wasm.to_string_lossy().to_string();
                KernelCommand::ModulesAdd { name: name.clone(), version: version.clone(), wasm: wasm_str }
            },
            ModuleSubcommands::Replace { name, version, wasm, admin } => {
                let wasm_str = wasm.to_string_lossy().to_string();
                KernelCommand::ModulesReplace { name: name.clone(), version: version.clone(), wasm: wasm_str }
            },
            ModuleSubcommands::List { admin } => KernelCommand::ModulesList,
        },
        Commands::Agent(cmd) => match &cmd.command {
            AgentSubcommands::Status { id } => KernelCommand::AgentStatus { id: id.clone() },
            AgentSubcommands::Kill { id } => KernelCommand::AgentStatus { id: id.clone() },
        },
        Commands::System(cmd) => match &cmd.action {
            SystemActions::State => KernelCommand::SystemState,
            SystemActions::Reset => KernelCommand::SystemState,
        },
        Commands::Ipc(cmd) => match &cmd.command {
            IpcSubcommands::Publish { topic, payload } => KernelCommand::IpcPublish { topic: topic.clone(), payload: payload.clone() },
            IpcSubcommands::Subscribe { topic } => KernelCommand::IpcSubscribe { topic: topic.clone() },
            IpcSubcommands::Recv { timeout } => KernelCommand::IpcRecv { timeout: *timeout },
            IpcSubcommands::ListTopics => KernelCommand::IpcListTopics,
        },
        Commands::Workspace(cmd) => match &cmd.command {
            WorkspaceSubcommands::Write { path, content } => KernelCommand::WorkspaceWrite { path: path.clone(), content: content.clone() },
            WorkspaceSubcommands::Read { path } => KernelCommand::WorkspaceRead { path: path.clone() },
            WorkspaceSubcommands::List { path } => KernelCommand::WorkspaceList { path: path.clone() },
            WorkspaceSubcommands::Snapshot => KernelCommand::WorkspaceSnapshot,
            WorkspaceSubcommands::Status => KernelCommand::WorkspaceStatus,
        },
        Commands::Debug(cmd) => match &cmd.command {
            DebugSubcommands::Kernel => KernelCommand::DebugKernel,
            DebugSubcommands::Memory => KernelCommand::DebugMemory,
            DebugSubcommands::Scheduler => KernelCommand::DebugScheduler,
            DebugSubcommands::Process => KernelCommand::DebugProcess,
            DebugSubcommands::Tracing => KernelCommand::DebugTracing,
        },
    };

    let request_bytes = serde_json::to_vec(&cmd)?;
    stream.write_all(&request_bytes)?;
    stream.shutdown(std::net::Shutdown::Write)?;

    let mut response_buffer = Vec::new();
    stream.read_to_end(&mut response_buffer)?;
    let response: KernelResponse = serde_json::from_slice(&response_buffer)?;

    match response {
        KernelResponse::Ok(msg) => println!("✅ {}", msg),
        KernelResponse::Error(err) => {
            eprintln!("❌ Error: {}", err);
            std::process::exit(1);
        }
    }

    Ok(())
}
