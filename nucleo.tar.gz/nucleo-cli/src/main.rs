//! CLI de administración para Nucleo Kernel.
//! Comunicación vía Unix Domain Sockets (UDS).

use anyhow::{anyhow, Result};
use clap::{Parser, Subcommand, Args};
use std::io::{Read, Write};
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::process::Command;
use serde::{Serialize, Deserialize};

#[derive(Parser)]
struct Cli {
    #[command(subcommand)]
    command: Commands,

    /// Activa el modo desarrollador (muestra tráfico JSON crudo y logs detallados)
    #[arg(short, long, global = true)]
    dev: bool,
}

#[derive(Subcommand)]
enum Commands {
    Modules(ModuleCommands),
    Agent(AgentCommands),
    System(SystemCommands),
    Ipc(IpcCommands),
    Workspace(WorkspaceCommands),
    Debug(DebugCommands),
    /// Control total del entorno (Codespace de GitHub)
    Space(SpaceCommands),
}

#[derive(Args)]
struct SpaceCommands {
    #[command(subcommand)]
    command: SpaceSubcommands,
}

#[derive(Subcommand)]
enum SpaceSubcommands {
    /// Muestra el estado de recursos del Codespace (RAM, CPU, Disco)
    Status,
    /// Sincroniza el estado actual del espacio con el repositorio de GitHub
    Sync { #[arg(long)] message: Option<String> },
    /// Reinicia el daemon del núcleo y limpia procesos huérfanos
    Restart,
    /// Muestra los logs del sistema del núcleo en tiempo real
    Logs { #[arg(short, long)] follow: bool },
}

#[derive(Args)]
struct ModuleCommands {
    #[command(subcommand)]
    command: ModuleSubcommands,
}

#[derive(Subcommand)]
enum ModuleSubcommands {
    List { #[arg(long)] admin: bool },
    Add { name: String, #[arg(long)] version: String, #[arg(long)] wasm: PathBuf, #[arg(long)] admin: bool },
    Replace { name: String, #[arg(long)] version: String, #[arg(long)] wasm: PathBuf, #[arg(long)] admin: bool },
    Unload { name: String, #[arg(long)] admin: bool },
    Info { name: String },
}

#[derive(Args)]
struct AgentCommands {
    #[command(subcommand)]
    command: AgentSubcommands,
}

#[derive(Subcommand)]
enum AgentSubcommands {
    List,
    Status { id: String },
    Create { id: String, name: String },
    Stop { id: String },
    Restart { id: String },
    Kill { id: String },
    Stats { id: String },
}

#[derive(Args)]
struct SystemCommands {
    #[command(subcommand)]
    action: SystemActions,
}

#[derive(Subcommand)]
enum SystemActions {
    State,
    Reset,
    Reboot,
    SafeMode { enable: bool },
    Quota { 
        agent_id: String,
        #[arg(long)] cpu: Option<f32>,
        #[arg(long)] ram: Option<usize>
    },
    Config { key: String, value: String },
}

#[derive(Args)]
struct IpcCommands {
    #[command(subcommand)]
    command: IpcSubcommands,
}

#[derive(Subcommand)]
enum IpcSubcommands {
    Publish { topic: String, payload: String },
    Subscribe { topic: String },
    Recv { timeout: u64 },
    ListTopics,
}

#[derive(Args)]
struct WorkspaceCommands {
    #[command(subcommand)]
    command: WorkspaceSubcommands,
}

#[derive(Subcommand)]
enum WorkspaceSubcommands {
    List { path: String },
    Write { path: String, content: String },
    Read { path: String },
    Files { path: String },
    Snapshot { 
        action: SnapshotAction,
        #[arg(long)] id: Option<String>
    },
    Status { id: String },
}

#[derive(clap::ValueEnum, Clone, Debug)]
enum SnapshotAction {
    Create,
    Restore,
}

#[derive(Args)]
struct DebugCommands {
    #[command(subcommand)]
    command: DebugSubcommands,
}

#[derive(Subcommand)]
enum DebugSubcommands {
    Kernel,
    Memory,
    Scheduler,
    Process,
    Tracing,
    Inspect { component: String },
}

#[derive(Serialize, Deserialize, Debug)]
pub enum KernelCommand {
    AgentList,
    AgentStatus { id: String },
    AgentCreate { id: String, name: String },
    AgentStop { id: String },
    AgentRestart { id: String },
    AgentKill { id: String },
    AgentStats { id: String },
    ModulesList { admin: bool },
    ModulesAdd { name: String, version: String, wasm: String },
    ModulesReplace { name: String, version: String, wasm: String },
    ModulesUnload { name: String, admin: bool },
    ModulesInfo { name: String },
    SystemState,
    SystemReset,
    SystemReboot,
    SystemSafeMode { enable: bool },
    SystemQuota { agent_id: String, cpu: Option<f32>, ram: Option<usize> },
    SystemConfig { key: String, value: String },
    IpcPublish { topic: String, payload: String },
    IpcSubscribe { topic: String },
    IpcRecv { timeout: u64 },
    IpcListTopics,
    WorkspaceList { path: String },
    WorkspaceWrite { path: String, content: String },
    WorkspaceRead { path: String },
    WorkspaceFiles { path: String },
    WorkspaceSnapshot { action: String, id: Option<String> },
    WorkspaceStatus { id: String },
    DebugKernel,
    DebugMemory,
    DebugScheduler,
    DebugProcess,
    DebugTracing,
    DebugInspect { component: String },
}

#[derive(Serialize, Deserialize, Debug)]
pub enum KernelResponse {
    Ok(String),
    Error(String),
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let socket_path = "/tmp/nucleo.sock";

    // 1. Manejo de comandos locales (CONTROL DEL ESPACIO / CODESPACE)
    if let Commands::Space(space_cmd) = &cli.command {
        return match &space_cmd.command {
            SpaceSubcommands::Status => {
                println!("📊 Estado del Codespace:");
                let output = Command::new("sh").arg("-c").arg("free -m && df -h /").output()?;
                println!("{}", String::from_utf8_lossy(&output.stdout));
                Ok(())
            },
            SpaceSubcommands::Sync { message } => {
                let msg = message.as_deref().unwrap_or("Nucleo Auto-Sync");
                println!("🔄 Sincronizando espacio con GitHub...");
                let status = Command::new("sh").arg("-c")
                    .arg(format!("git add . && git commit -m \"{}\" && git push", msg))
                    .status()?;
                if status.success() {
                    println!("✅ Espacio sincronizado correctamente.");
                } else {
                    eprintln!("❌ Falló la sincronización.");
                }
                Ok(())
            },
            SpaceSubcommands::Restart => {
                println!("♻️ Reiniciando Daemon del Núcleo...");
                let _ = Command::new("pkill").arg("-f").arg("nucleo-kernel").status();
                let _ = Command::new("nohup").arg("./target/release/nucleo-kernel").arg("&").status();
                println!("✅ Daemon reiniciado.");
                Ok(())
            },
            SpaceSubcommands::Logs { follow } => {
                let arg = if *follow { "-f" } else { "" };
                let cmd_str = format!("tail {} /var/log/nucleo.log", arg);
                println!("📜 Mostrando logs del núcleo...");
                let mut child = Command::new("sh").arg("-c").arg(cmd_str).spawn()?;
                child.wait()?;
                Ok(())
            },
        };
    }

    // 2. Manejo de comandos del Kernel vía UDS
    let mut stream = UnixStream::connect(socket_path)
        .map_err(|e| anyhow!("No se pudo conectar al kernel en {}. ¿Está corriendo el daemon? ({})", socket_path, e))?;

    let cmd = match &cli.command {
        Commands::Modules(cmd) => match &cmd.command {
            ModuleSubcommands::Add { name, version, wasm, admin } => {
                KernelCommand::ModulesAdd { name: name.clone(), version: version.clone(), wasm: wasm.to_string_lossy().to_string() }
            },
            ModuleSubcommands::Replace { name, version, wasm, admin } => {
                KernelCommand::ModulesReplace { name: name.clone(), version: version.clone(), wasm: wasm.to_string_lossy().to_string() }
            },
            ModuleSubcommands::List { admin } => KernelCommand::ModulesList { admin: *admin },
            ModuleSubcommands::Unload { name, admin } => KernelCommand::ModulesUnload { name: name.clone(), admin: *admin },
            ModuleSubcommands::Info { name } => KernelCommand::ModulesInfo { name: name.clone() },
        },
        Commands::Agent(cmd) => match &cmd.command {
            AgentSubcommands::List => KernelCommand::AgentList,
            AgentSubcommands::Status { id } => KernelCommand::AgentStatus { id: id.clone() },
            AgentSubcommands::Create { id, name } => KernelCommand::AgentCreate { id: id.clone(), name: name.clone() },
            AgentSubcommands::Stop { id } => KernelCommand::AgentStop { id: id.clone() },
            AgentSubcommands::Restart { id } => KernelCommand::AgentRestart { id: id.clone() },
            AgentSubcommands::Kill { id } => KernelCommand::AgentKill { id: id.clone() },
            AgentSubcommands::Stats { id } => KernelCommand::AgentStats { id: id.clone() },
        },
        Commands::System(cmd) => match &cmd.action {
            SystemActions::State => KernelCommand::SystemState,
            SystemActions::Reset => KernelCommand::SystemReset,
            SystemActions::Reboot => KernelCommand::SystemReboot,
            SystemActions::SafeMode { enable } => KernelCommand::SystemSafeMode { enable: *enable },
            SystemActions::Quota { agent_id, cpu, ram } => KernelCommand::SystemQuota { 
                agent_id: agent_id.clone(), 
                cpu: *cpu, 
                ram: *ram 
            },
            SystemActions::Config { key, value } => KernelCommand::SystemConfig { key: key.clone(), value: value.clone() },
        },
        Commands::Ipc(cmd) => match &cmd.command {
            IpcSubcommands::Publish { topic, payload } => KernelCommand::IpcPublish { topic: topic.clone(), payload: payload.clone() },
            IpcSubcommands::Subscribe { topic } => KernelCommand::IpcSubscribe { topic: topic.clone() },
            IpcSubcommands::Recv { timeout } => KernelCommand::IpcRecv { timeout: *timeout },
            IpcSubcommands::ListTopics => KernelCommand::IpcListTopics,
        },
        Commands::Workspace(cmd) => match &cmd.command {
            WorkspaceSubcommands::Write { path, content } => KernelCommand::WorkspaceWrite { path: path.clone(), content: content.clone() },
            WorkspaceSubcommands::Read { path } => KernelCommand::WorkspaceRead { path: path.clone() },
            WorkspaceSubcommands::List { path } => KernelCommand::WorkspaceList { path: path.clone() },
            WorkspaceSubcommands::Files { path } => KernelCommand::WorkspaceFiles { path: path.clone() },
            WorkspaceSubcommands::Snapshot { action, id } => KernelCommand::WorkspaceSnapshot { 
                action: format!("{:?}", action), 
                id: id.clone() 
            },
            WorkspaceSubcommands::Status { id } => KernelCommand::WorkspaceStatus { id: id.clone() },
        },
        Commands::Debug(cmd) => match &cmd.command {
            DebugSubcommands::Kernel => KernelCommand::DebugKernel,
            DebugSubcommands::Memory => KernelCommand::DebugMemory,
            DebugSubcommands::Scheduler => KernelCommand::DebugScheduler,
            DebugSubcommands::Process => KernelCommand::DebugProcess,
            DebugSubcommands::Tracing => KernelCommand::DebugTracing,
            DebugSubcommands::Inspect { component } => KernelCommand::DebugInspect { component: component.clone() },
        },
        Commands::Space(_) => unreachable!(),
    };

    let request_bytes = serde_json::to_vec(&cmd)?;
    if cli.dev {
        println!("🛠️ [DEV] Outgoing Request: {}", String::from_utf8_lossy(&request_bytes));
    }
    stream.write_all(&request_bytes)?;
    stream.shutdown(std::net::Shutdown::Write)?;

    let mut response_buffer = Vec::new();
    stream.read_to_end(&mut response_buffer)?;
    if cli.dev {
        println!("🛠️ [DEV] Incoming Response: {}", String::from_utf8_lossy(&response_buffer));
    }
    let response: KernelResponse = serde_json::from_slice(&response_buffer)?;

    match response {
        KernelResponse::Ok(msg) => println!("✅ {}", msg),
        KernelResponse::Error(err) => {
            eprintln!("❌ Error: {}", err);
            std::process::exit(1);
        }
    }

    Ok(())
}
